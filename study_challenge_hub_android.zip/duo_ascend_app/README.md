# Study Challenge Hub — Android app starter

This is a Flutter **Android app project**, not a website. It includes email/password sign-in, personal participant profiles, multiple challenge spaces, individual leaderboard, team leaderboard with expandable member lists, daily study/cam/snaps/score entries, challenge notice board, live-update colour treatment, and basic admin tools for creating challenges, adding display-name participants, promoting an existing account to admin, and creating notices.

## Important: backend setup is required
A working personal account system and shared live data require a Firebase project owned by you. This ZIP cannot contain your private Firebase credentials, and the app is not connected to a backend until you configure it.

## Build on a computer
1. Install Flutter SDK and Android Studio.
2. Unzip this folder and open a terminal in `study_challenge_hub`.
3. Run `flutter pub get`.
4. Create a Firebase project at https://console.firebase.google.com/ and add an Android app with package ID `com.example.study_challenge_hub` (or change the Android package to match your Firebase app).
5. Install Firebase CLI and FlutterFire CLI, then run `flutterfire configure`. Add the generated `firebase_options.dart` and update `main.dart` to use `DefaultFirebaseOptions.currentPlatform` if the CLI generates that file.
6. In Firebase Authentication, enable **Email/Password**. Create a Cloud Firestore database.
7. Run `flutter run` to test on an Android device, or `flutter build apk --release` to make an APK.

## Set yourself as the first admin
1. Create your account in the app.
2. In Firebase Console → Firestore → `users` → your UID document, change `role` from `participant` to `admin`.
3. Sign out and sign back in. Admin tools will appear.

## Current starter limitations (before production)
- This is a starter implementation, not a production-ready deployment. It has not been compiled or tested against your Firebase project.
- Add Firestore Security Rules before inviting anyone. Do not launch with open database rules. Enforce admin-only edits, challenge membership, private entry passwords, and score validation on the server.
- “Add participant by name” adds a display-only roster entry, not a login account. For a participant to log in with a personal account, they must sign up with email/password; then the admin can promote/manage their membership in a fuller production workflow.
- Score editing/deleting, changing challenge leaders/managers, invitation links, password-gated entry enforcement, push notification delivery, and full user removal are listed as requested next features but need secure backend workflows. The current screen is the initial foundation; notice cards are live-updating in Firestore, but push notifications require Firebase Cloud Messaging setup and server-side sending.
- Add App Check, proper Firestore rules, data export/backups, abuse prevention, and privacy/consent text before public release.

## Data layout
- `users/{uid}` — personal profile and role
- `challenges/{challengeId}` — challenge settings and owner/leader/manager IDs
- `challenges/{challengeId}/stats/{entryId}` — daily entries
- `challenges/{challengeId}/participants/{participantId}` — display-only roster records
- `challenges/{challengeId}/notices/{noticeId}` — notices and live updates
